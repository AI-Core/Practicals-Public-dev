def function_1():
    print('This is function 1 in module 1')

def function_2():
    print('This is function 2 in module 1')