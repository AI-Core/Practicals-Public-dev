def function_1():
    print('This is function 1 in module 2')

x = 'Hello, I am in module 2'